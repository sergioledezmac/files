# AngularJS BootStrap 3 Modal Dialogs

A Pen created on CodePen.io. Original URL: [https://codepen.io/sergiolc/pen/NWOpPWp](https://codepen.io/sergiolc/pen/NWOpPWp).

A dialog/modal service written in AngularJS, creates predefined easy to use dialogs (error,wait,notify,confirm,create) with Angular UI and Bootstrap 3